import React from 'react';
import * as styles from './ProductAd.module.css';
export default props => (
  <div className={styles.ProductAd}>
   <div className={styles.ad}></div>

  </div>
);